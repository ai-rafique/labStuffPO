/*

Author(s): Kurt Vonnegut (http://www.guntheroth.com)
           David Holmqvist <daae19@student.bth.se>

*/

#include <fstream>
#include <iostream>
#include <iterator>
#include <sstream>
#include <string>

void file_reader(std::istream& is, std::string& result)
{
    result.assign(std::istreambuf_iterator<char> { is.rdbuf() }, std::istreambuf_iterator<char> {});
}

int main(int argc, char** argv)
{
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " [test_rounds]" << std::endl;
        std::exit(1);
    }

    const unsigned int test_rounds { static_cast<unsigned int>(atoi(argv[1])) };

    std::ifstream f {};

    f.open("lorem_ipsum.txt");

    if (!f) {
        std::cerr << "Failed to open lorem_ipsum.txt" << std::endl;
        return 1;
    }

    std::string file_string {};

    for (unsigned int i { 0 }; i < test_rounds; i++) {
        file_reader(f, file_string);
    }

    return 0;
}
