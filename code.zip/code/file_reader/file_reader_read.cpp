/*

Author(s): Kurt Vonnegut (http://www.guntheroth.com)
           David Holmqvist <daae19@student.bth.se>

*/

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

std::streamoff stream_size(std::istream& f)
{
    std::istream::pos_type current_pos { f.tellg() };
    if (-1 == current_pos)
        return -1;
    f.seekg(0, std::istream::end);
    std::istream::pos_type end_pos { f.tellg() };
    f.seekg(current_pos);
    return end_pos - current_pos;
}

bool file_reader(std::istream& f, std::string& result)
{
    std::streamoff len { stream_size(f) };
    if (len == -1)
        return false;

    result.resize(static_cast<std::string::size_type>(len));

    f.read(&result[0], result.length());
    return true;
}

int main(int argc, char** argv)
{
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " [test_rounds]" << std::endl;
        std::exit(1);
    }

    const unsigned int test_rounds { static_cast<unsigned int>(atoi(argv[1])) };

    std::ifstream f {};

    f.open("lorem_ipsum.txt");

    if (!f) {
        std::cerr << "Failed to open lorem_ipsum.txt" << std::endl;
        return 1;
    }

    std::string file_string {};

    for (unsigned int i { 0 }; i < test_rounds; i++) {
        file_reader(f, file_string);
    }

    return 0;
}
