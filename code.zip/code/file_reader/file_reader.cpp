/*

Author(s): Kurt Vonnegut (http://www.guntheroth.com)
           David Holmqvist <daae19@student.bth.se>

*/

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

std::string file_reader(char const* fname)
{
    std::ifstream f {};
    f.open(fname);
    if (!f) {
        std::cout << "Can't open " << fname
                  << " for reading" << std::endl;
        return "";
    }

    std::stringstream s {};
    std::copy(std::istreambuf_iterator<char> { f.rdbuf() }, std::istreambuf_iterator<char> {}, std::ostreambuf_iterator<char> { s });
    return s.str();
}

int main(int argc, char** argv)
{
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " [test_rounds]" << std::endl;
        std::exit(1);
    }

    const unsigned int test_rounds { static_cast<unsigned int>(atoi(argv[1])) };

    for (unsigned int i { 0 }; i < test_rounds; i++) {
        file_reader("lorem_ipsum.txt");
    }
    return 0;
}
