/*

Author(s): David Holmqvist <daae19@student.bth.se>
           Charles Smith <cas275@pitt.edu> (https://github.com/chuckie512/hpc-course/blob/master/hw3/strassen.c)

*/

#include "matrix.hpp"
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <pthread.h>

#if defined(NAIVE_PARALLEL) || defined(STRASSEN_PARALLEL)
static const Matrix* A {};
static const Matrix* B {};
static Matrix* C {};
#endif

#if defined(STRASSEN_PARALLEL)
static Matrix* m1 {};
static Matrix* m2 {};
static Matrix* m3 {};
static Matrix* m4 {};
static Matrix* m5 {};
static Matrix* m6 {};
static Matrix* m7 {};

static Matrix* c1 {};
static Matrix* c2 {};
static Matrix* c3 {};
static Matrix* c4 {};
#endif

#if defined(NAIVE_PARALLEL)
void* matmul_thread(void* arg)
{
    unsigned int tid { *reinterpret_cast<unsigned int*>(arg) };
    unsigned int dimension { A->get_dimension() };
    unsigned int thread_n { A->get_thread_n() };
    unsigned int block_size { dimension / thread_n };
    unsigned int row_begin { tid * block_size };
    unsigned int row_end { row_begin + block_size };

    for (unsigned int i { row_begin }; i < row_end; i++) {
        for (unsigned int j { 0 }; j < dimension; j++) {
            for (unsigned int k { 0 }; k < dimension; k++) {
                (*C)(i, j) += (*A)(i, k) * (*B)(k, j);
            }
        }
    }

    return nullptr;
}
#endif

Matrix::Matrix()
    : matrix { nullptr }
    , dimension { 0 }
{
}

Matrix::Matrix(unsigned int dimension, double init_value)
    : matrix { new double[dimension * dimension] }
    , dimension { dimension }
{
    fill(init_value);
}

void Matrix::fill(double value)
{
    std::fill_n(matrix, dimension * dimension, value);
}

Matrix::~Matrix()
{
    if (matrix) {
        delete[] matrix;
    }
}

unsigned int Matrix::get_dimension() const
{
    return dimension;
}

Matrix::Matrix(const Matrix& other)
    : dimension { other.dimension }
{
    std::memcpy(matrix, other.matrix, dimension * dimension * sizeof(double));
}

Matrix::Matrix(Matrix&& other)
    : dimension { other.dimension }
    , matrix { other.matrix }
{
    other.matrix = nullptr;
    other.dimension = 0;
}

Matrix& Matrix::operator=(const Matrix& other)
{
    if (this == &other) {
        return *this;
    }

    if (dimension != other.dimension) {
        delete[] matrix;
        matrix = new double[other.dimension * other.dimension * sizeof(double)];
        dimension = other.dimension;
    }

    std::memcpy(matrix, other.matrix, dimension * dimension * sizeof(double));

    return *this;
}

Matrix& Matrix::operator=(Matrix&& other)
{
    if (this == &other) {
        return *this;
    }

    this->~Matrix();

    matrix = other.matrix;
    dimension = other.dimension;

    other.matrix = nullptr;
    other.dimension = 0;

    return *this;
}

Matrix Matrix::operator+(const Matrix& other)
{
    Matrix result { dimension };

    for (int i { 0 }; i < dimension; i++) {
        for (int j { 0 }; j < dimension; j++) {
            result(i, j) = (*this)(i, j) + other(i, j);
        }
    }

    return result;
}

#if defined(NAIVE_PARALLEL)
void Matrix::set_thread_n(unsigned int thread_n)
{
    this->thread_n = thread_n;
}

unsigned int Matrix::get_thread_n() const
{
    return thread_n;
}
#endif

Matrix Matrix::operator-(const Matrix& other)
{
    Matrix result { dimension };

    for (int i { 0 }; i < dimension; i++) {
        for (int j { 0 }; j < dimension; j++) {
            result(i, j) = (*this)(i, j) - other(i, j);
        }
    }

    return result;
}

Matrix& Matrix::operator+=(const Matrix& other)
{
    for (int i { 0 }; i < dimension; i++) {
        for (int j { 0 }; j < dimension; j++) {
            (*this)(i, j) += other(i, j);
        }
    }

    return *this;
}

void Matrix::randomize(unsigned int upper_limit)
{
    std::srand(std::time(nullptr));

    for (int i { 0 }; i < dimension; i++) {
        for (int j { 0 }; j < dimension; j++) {
            (*this)(i, j) = std::rand() % upper_limit;
        }
    }
}

#if defined(STRASSEN_PARALLEL)
#include <cmath>

void Matrix::ensure_perfect_squared_dimension()
{
    unsigned int square_root { static_cast<unsigned int>(std::sqrt(dimension * 1.0)) };
    bool is_perfect_square { square_root * square_root == dimension };

    if (!is_perfect_square) {
        unsigned int half { square_root + 1 };
        unsigned int new_dimension { half * half };
        Matrix new_matrix { new_dimension, 0 };

        for (int i { 0 }; i < dimension; i++) {
            for (int j { 0 }; j < dimension; j++) {
                new_matrix(i, j) = (*this)(i, j);
            }
        }

        actual_dimension = dimension;
        *this = std::move(new_matrix);
    } else {
        actual_dimension = dimension;
    }
}

void* calc_m1(void* arg)
{
    unsigned int dimension { *reinterpret_cast<unsigned int*>(arg) };
    unsigned int new_dimension { dimension / 2 };

    Matrix a { new_dimension };
    Matrix b { new_dimension };

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            a(i, j) = (*A)(i, j) + (*A)(new_dimension + i, new_dimension + j);
            b(i, j) = (*B)(i, j) + (*B)(new_dimension + i, new_dimension + j);
        }
    }

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            for (int k { 0 }; k < new_dimension; k++) {
                (*m1)(i, j) += a(i, k) * b(k, j);
            }
        }
    }

    return nullptr;
}

void* calc_m2(void* arg)
{
    unsigned int dimension { *reinterpret_cast<unsigned int*>(arg) };
    unsigned int new_dimension { dimension / 2 };

    Matrix a { new_dimension };

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            a(i, j) = (*A)(new_dimension + i, j) + (*A)(new_dimension + i, new_dimension + j);
        }
    }

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            for (int k { 0 }; k < new_dimension; k++) {
                (*m2)(i, j) += a(i, k) * (*B)(k, j);
            }
        }
    }

    return nullptr;
}

void* calc_m3(void* arg)
{
    unsigned int dimension { *reinterpret_cast<unsigned int*>(arg) };
    unsigned int new_dimension { dimension / 2 };

    Matrix b { new_dimension };

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            b(i, j) = (*B)(i, new_dimension + j) - (*B)(new_dimension + i, new_dimension + j);
        }
    }

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            for (int k { 0 }; k < new_dimension; k++) {
                (*m3)(i, j) += (*A)(i, k) * b(k, j);
            }
        }
    }

    return nullptr;
}

void* calc_m4(void* arg)
{
    unsigned int dimension { *reinterpret_cast<unsigned int*>(arg) };
    unsigned int new_dimension { dimension / 2 };

    Matrix b { new_dimension };

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            b(i, j) = (*B)(new_dimension + i, j) - (*B)(i, j);
        }
    }

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            for (int k { 0 }; k < new_dimension; k++) {
                (*m4)(i, j) += (*A)(new_dimension + i, new_dimension + k) * b(k, j);
            }
        }
    }

    return nullptr;
}

void* calc_m5(void* arg)
{
    unsigned int dimension { *reinterpret_cast<unsigned int*>(arg) };
    unsigned int new_dimension { dimension / 2 };

    Matrix a { new_dimension };

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            a(i, j) = (*A)(i, j) + (*A)(i, new_dimension + j);
        }
    }

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            for (int k { 0 }; k < new_dimension; k++) {
                (*m5)(i, j) += a(i, k) * (*B)(new_dimension + k, new_dimension + j);
            }
        }
    }

    return nullptr;
}

void* calc_m6(void* arg)
{
    unsigned int dimension { *reinterpret_cast<unsigned int*>(arg) };
    unsigned int new_dimension { dimension / 2 };

    Matrix a { new_dimension };
    Matrix b { new_dimension };

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            a(i, j) = (*A)(new_dimension + i, j) - (*A)(i, j);
            b(i, j) = (*B)(i, j) + (*B)(i, new_dimension + j);
        }
    }

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            for (int k { 0 }; k < new_dimension; k++) {
                (*m6)(i, j) += a(i, k) * b(k, j);
            }
        }
    }

    return nullptr;
}

void* calc_m7(void* arg)
{
    unsigned int dimension { *reinterpret_cast<unsigned int*>(arg) };
    unsigned int new_dimension { dimension / 2 };

    Matrix a { new_dimension };
    Matrix b { new_dimension };

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            a(i, j) = (*A)(i, new_dimension + j) - (*A)(new_dimension + i, new_dimension + j);
            b(i, j) = (*B)(new_dimension + i, j) + (*B)(new_dimension + i, new_dimension + j);
        }
    }

    for (int i { 0 }; i < new_dimension; i++) {
        for (int j { 0 }; j < new_dimension; j++) {
            for (int k { 0 }; k < new_dimension; k++) {
                (*m7)(i, j) += a(i, k) * b(k, j);
            }
        }
    }

    return nullptr;
}

void* calc_c1(void* arg)
{
    unsigned int dimension { *reinterpret_cast<unsigned int*>(arg) };

    for (int i { 0 }; i < dimension; i++) {
        for (int j { 0 }; j < dimension; j++) {
            (*c1)(i, j) = (*m1)(i, j) + (*m4)(i, j) - (*m5)(i, j) + (*m7)(i, j);
        }
    }

    return nullptr;
}

void* calc_c2(void* arg)
{
    unsigned int dimension { *reinterpret_cast<unsigned int*>(arg) };

    for (int i { 0 }; i < dimension; i++) {
        for (int j { 0 }; j < dimension; j++) {
            (*c2)(i, j) = (*m3)(i, j) + (*m5)(i, j);
        }
    }

    return nullptr;
}

void* calc_c3(void* arg)
{
    unsigned int dimension { *reinterpret_cast<unsigned int*>(arg) };

    for (int i { 0 }; i < dimension; i++) {
        for (int j { 0 }; j < dimension; j++) {
            (*c3)(i, j) = (*m2)(i, j) + (*m4)(i, j);
        }
    }

    return nullptr;
}

void* calc_c4(void* arg)
{
    unsigned int dimension { *reinterpret_cast<unsigned int*>(arg) };

    for (int i { 0 }; i < dimension; i++) {
        for (int j { 0 }; j < dimension; j++) {
            (*c4)(i, j) = ((*m1)(i, j) - (*m2)(i, j)) + ((*m3)(i, j) + (*m6)(i, j));
        }
    }

    return nullptr;
}
#endif

Matrix Matrix::operator*(const Matrix& other)
{
    Matrix result { dimension };

#if defined(NAIVE_PARALLEL) || defined(STRASSEN_PARALLEL)
    A = this;
    B = &other;
    C = &result;
#endif

#if defined(NAIVE)
    for (int i { 0 }; i < dimension; i++) {
        for (int j { 0 }; j < dimension; j++) {
            for (int k { 0 }; k < dimension; k++) {
                result(i, j) += (*this)(i, k) * other(k, j);
            }
        }
    }
#elif defined(NAIVE_PARALLEL)
    pthread_t threads[thread_n];
    unsigned int thread_args[thread_n];

    for (unsigned int i { 0 }; i < thread_n; i++) {
        thread_args[i] = i;
        if (pthread_create(&threads[i], nullptr, matmul_thread, &thread_args[i]) != 0) {
            std::cerr << "Failed to spawn new thread with thread_id " << i << std::endl;
            std::exit(1);
        }
    }

    for (int i { 0 }; i < thread_n; i++) {
        pthread_join(threads[i], nullptr);
    }
#elif defined(STRASSEN_PARALLEL)
#define M_THREADS 7
#define C_THREADS 4
    unsigned int new_dimension { dimension / 2 };

    Matrix _m1 { new_dimension };
    Matrix _m2 { new_dimension };
    Matrix _m3 { new_dimension };
    Matrix _m4 { new_dimension };
    Matrix _m5 { new_dimension };
    Matrix _m6 { new_dimension };
    Matrix _m7 { new_dimension };

    m1 = &_m1;
    m2 = &_m2;
    m3 = &_m3;
    m4 = &_m4;
    m5 = &_m5;
    m6 = &_m6;
    m7 = &_m7;

    pthread_t m_threads[M_THREADS];

    pthread_create(&m_threads[0], nullptr, &calc_m1, &dimension);
    pthread_create(&m_threads[1], nullptr, &calc_m2, &dimension);
    pthread_create(&m_threads[2], nullptr, &calc_m3, &dimension);
    pthread_create(&m_threads[3], nullptr, &calc_m4, &dimension);
    pthread_create(&m_threads[4], nullptr, &calc_m5, &dimension);
    pthread_create(&m_threads[5], nullptr, &calc_m6, &dimension);
    pthread_create(&m_threads[6], nullptr, &calc_m7, &dimension);

    for (int i { 0 }; i < M_THREADS; i++) {
        pthread_join(m_threads[i], nullptr);
    }

    Matrix _c1 { new_dimension };
    Matrix _c2 { new_dimension };
    Matrix _c3 { new_dimension };
    Matrix _c4 { new_dimension };

    c1 = &_c1;
    c2 = &_c2;
    c3 = &_c3;
    c4 = &_c4;

    pthread_t c_threads[C_THREADS];
    pthread_create(&c_threads[0], nullptr, calc_c1, &new_dimension);
    pthread_create(&c_threads[1], nullptr, calc_c2, &new_dimension);
    pthread_create(&c_threads[2], nullptr, calc_c3, &new_dimension);
    pthread_create(&c_threads[3], nullptr, calc_c4, &new_dimension);

    for (int i { 0 }; i < C_THREADS; i++) {
        pthread_join(c_threads[i], nullptr);
    }

    for (int i { 0 }; i < dimension; i++) {
        for (int j { 0 }; j < dimension; j++) {
            if (i < new_dimension && j < new_dimension) {
                (*C)(i, j) = _c1(i, j);
            } else if (i >= new_dimension && j < new_dimension) {
                (*C)(i, j) = _c3(i - new_dimension, j);
            } else if (i < new_dimension && j >= new_dimension) {
                (*C)(i, j) = _c2(i, j - new_dimension);
            } else if (i >= new_dimension && j >= new_dimension) {
                (*C)(i, j) = _c4(i - new_dimension, j - new_dimension);
            }
        }
    }

    m1 = m2 = m3 = m4 = m5 = m6 = m7 = nullptr;
    c1 = c2 = c3 = c4 = nullptr;
#undef M_THREADS
#undef C_THREADS
#else
#warning No multiplication operator defined for Matrix class. To generate, define one symbol of NAIVE, NAIVE_PARALLEL, or STRASSEN_PARALLEL.
#endif
    return result;
}
