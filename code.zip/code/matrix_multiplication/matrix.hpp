/*

Author(s): David Holmqvist <daae19@student.bth.se>

*/

#include <iostream>

#if !defined(MATRIX_HPP)
#define MATRIX_HPP

class Matrix {
private:
    double* matrix;
    unsigned int dimension;

#if defined(STRASSEN_PARALLEL)
    unsigned int actual_dimension;
#endif

#if defined(NAIVE_PARALLEL)
    unsigned int thread_n;
#endif

    friend void swap(Matrix& lhs, Matrix& rhs)
    {
        unsigned int temp_dimension { lhs.dimension };
        double* temp_matrix { lhs.matrix };

        lhs.dimension = rhs.dimension;
        lhs.matrix = rhs.matrix;

        rhs.dimension = temp_dimension;
        rhs.matrix = temp_matrix;
    }

    friend std::ostream& operator<<(std::ostream& os, const Matrix& m)
    {
        unsigned int dimension {};

#if defined(STRASSEN_PARALLEL)
        dimension = m.actual_dimension;
#else
        dimension = m.dimension;
#endif

        os << dimension << " x " << dimension << " matrix" << std::endl;
        os << "[ ";

        for (int i { 0 }; i < dimension; i++) {
            if (i != 0) {
                os << "  ";
            }
            os << "[";
            for (int j { 0 }; j < dimension; j++) {
                os << " " << m(i, j) << " ";
            }
            os << "]";
            if (i != dimension - 1) {
                os << std::endl;
            }
        }
        os << " ]" << std::endl;
        return os;
    }

public:
    Matrix();
    void fill(double value);
    Matrix(unsigned int dimension, double init_value = 0);
    ~Matrix();
    unsigned int get_dimension() const;
    Matrix(const Matrix& other);
    Matrix(Matrix&& other);
    Matrix& operator=(const Matrix& other);
    Matrix& operator=(Matrix&& other);
    Matrix operator+(const Matrix& other);

#if defined(NAIVE_PARALLEL)
    void set_thread_n(unsigned int thread_n);
    unsigned int get_thread_n() const;
#endif

#if defined(STRASSEN_PARALLEL)
    void ensure_perfect_squared_dimension();
#endif

    Matrix operator-(const Matrix& other);
    Matrix& operator+=(const Matrix& other);
    Matrix operator*(const Matrix& other);

    inline double operator()(unsigned int x, unsigned int y) const
    {
        return matrix[x * dimension + y];
    }

    inline double& operator()(unsigned int x, unsigned int y)
    {
        return matrix[x * dimension + y];
    }

    void randomize(unsigned int upper_limit = 50);
};

#endif