/*

Author(s): David Holmqvist <daae19@student.bth.se>

*/

#include "matrix.hpp"
#include <cmath>
#include <cstdlib>
#include <iostream>

int main(int argc, char** argv)
{
#if defined(NAIVE_PARALLEL)
    if (argc < 4) {
        std::cerr << "Usage: " << argv[0] << " [dimension] [test_rounds] [threads]" << std::endl;
        std::exit(1);
    }
#elif defined(NAIVE) || defined(STRASSEN_PARALLEL)
    if (argc < 3) {
        std::cerr << "Usage: " << argv[0] << " [dimension] [test_rounds]" << std::endl;
        std::exit(1);
    }
#endif

    const unsigned int dimension { static_cast<unsigned int>(std::atoi(argv[1])) };
    const unsigned int test_rounds { static_cast<unsigned int>(std::atoi(argv[2])) };

#if defined(NAIVE_PARALLEL)
    const unsigned int thread_n { static_cast<unsigned int>(std::atoi(argv[3])) };

    if (dimension % thread_n != 0) {
        std::cerr << dimension << " (dimension) must be divisible by " << thread_n << " (threads)" << std::endl;
        std::exit(1);
    }
#endif

    Matrix A { dimension, 1 };
    Matrix B { dimension, 2 };
    Matrix C { dimension };

#if defined(STRASSEN_PARALLEL)
    A.ensure_perfect_squared_dimension();
    B.ensure_perfect_squared_dimension();
    C.ensure_perfect_squared_dimension();
#endif

#if defined(NAIVE_PARALLEL)
    A.set_thread_n(thread_n);
#endif

    for (unsigned int i { 0 }; i < test_rounds; i++) {
        C = A * B;
        //std::cout << C;
    }

    return 0;
}
