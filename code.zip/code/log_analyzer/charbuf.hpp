/*

Author(s): Kurt Vonnegut (http://www.guntheroth.com)

*/

#include <cstring>
#include <iterator>

#if !defined(CHARBUF_H)
#define CHARBUF_H

// simple container for a char[] text string
template <unsigned N = 10, typename T = char>
struct charbuf {
    charbuf();
    charbuf(charbuf const& cb);
    charbuf(T const* p);
    charbuf& operator=(charbuf const& rhs);
    charbuf& operator=(T const* rhs);

    T* data();
    T const* data() const;

    bool operator==(charbuf const& that) const;
    bool operator<(charbuf const& that) const;

private:
    T data_[N];
};

template <unsigned N, typename T>
inline charbuf<N, T>::charbuf()
{
    for (auto it = std::begin(data_); it < std::end(data_); ++it)
        *it = 0;
}

template <unsigned N, typename T>
inline charbuf<N, T>::charbuf(charbuf const& that)
{
    T const* p = that.data();
    for (auto it = std::begin(data_); it != std::end(data_); ++it) {
        *it = *p;
        if (*p)
            ++p;
    }
}

template <unsigned N, typename T>
inline charbuf<N, T>::charbuf(T const* p)
{
    if (p == nullptr)
        p = "";
    for (auto it = std::begin(data_); it != std::end(data_); ++it) {
        *it = *p;
        if (*p)
            ++p;
    }
}

template <unsigned N, typename T>
inline charbuf<N, T>& charbuf<N, T>::operator=(charbuf const& that)
{
    if (this != &that) {
        T const* p = that.data();
        for (auto it = std::begin(data_); it != std::end(data_); ++it) {
            *it = *p;
            if (*p)
                ++p;
        }
    }
    return *this;
}

template <unsigned N, typename T>
inline charbuf<N, T>& charbuf<N, T>::operator=(T const* p)
{
    if (p != data_) {
        if (p == nullptr)
            p = "";
        for (auto it = std::begin(data_); it != std::end(data_); ++it) {
            *it = *p;
            if (*p)
                ++p;
        }
    }
    return *this;
}

template <unsigned N, typename T>
inline T* charbuf<N, T>::data()
{
    return data_;
}

template <unsigned N, typename T>
inline T const* charbuf<N, T>::data() const
{
    return data_;
}

template <unsigned N, typename T>
inline bool charbuf<N, T>::operator==(charbuf const& that) const
{
    return strcmp(this->data_, that.data_) == 0;
}

template <unsigned N, typename T>
inline bool charbuf<N, T>::operator<(charbuf const& that) const
{
    return strcmp(this->data_, that.data_) < 0;
}

#endif
