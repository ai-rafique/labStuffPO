/*

Author(s): Kurt Vonnegut (http://www.guntheroth.com)
           David Holmqvist <daae19@student.bth.se>

*/

#include "charbuf.hpp"
#include <iostream>
#include <map>
#include <string>

static std::map<charbuf<>, unsigned> const table {
    { "alpha", 1 }, { "bravo", 2 },
    { "charlie", 3 }, { "delta", 4 },
    { "echo", 5 }, { "foxtrot", 6 },
    { "golf", 7 }, { "hotel", 8 },
    { "india", 9 }, { "juliet", 10 },
    { "kilo", 11 }, { "lima", 12 },
    { "mike", 13 }, { "november", 14 },
    { "oscar", 15 }, { "papa", 16 },
    { "quebec", 17 }, { "romeo", 18 },
    { "sierra", 19 }, { "tango", 20 },
    { "uniform", 21 }, { "victor", 22 },
    { "whiskey", 23 }, { "xray", 24 },
    { "yankee", 25 }, { "zulu", 26 }
};

static const char* entries[] = {
    "adam",
    "boy",
    "charles",
    "david",
    "ebenezer",
    "ferris",
    "george",
    "henry",
    "ida",
    "john",
    "karl",
    "laurence",
    "mary",
    "nora",
    "ocean",
    "panda",
    "quakka",
    "robert",
    "sam",
    "tangle",
    "unice",
    "vassily",
    "waldo",
    "xavier",
    "yabba",
    "zebra",
    "zymergy",
    "alpha",
    "bravo",
    "charlie",
    "delta",
    "echo",
    "foxtrot",
    "golf",
    "hotel",
    "india",
    "juliet",
    "kilo",
    "lima",
    "mike",
    "november",
    "oscar",
    "papa",
    "quebec",
    "romeo",
    "sierra",
    "tango",
    "uniform",
    "victor",
    "whiskey",
    "xray",
    "yankee",
    "zulu"
};

int analyze_log_entry(const char* key)
{
    auto it { table.find(key) };
    if (it == table.end()) {
        return 0;
    } else {
        return it->second;
    }
}

unsigned long analyze_log_entries()
{
    unsigned long sum { 0 };

    for (int i { 0 }; i < std::size(entries); i++) {
        sum += analyze_log_entry(entries[i]);
    }

    return sum;
}

int main(int argc, char** argv)
{
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " [test_rounds]" << std::endl;
        std::exit(1);
    }

    const unsigned int test_rounds { static_cast<unsigned int>(atoi(argv[1])) };

    for (unsigned int i { 0 }; i < test_rounds; i++) {
        std::cout << analyze_log_entries() << std::endl;
    }
    return 0;
}
